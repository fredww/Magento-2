# Magento-2
The payment extension for Magento 2, support WeChat Pay and Alipay
